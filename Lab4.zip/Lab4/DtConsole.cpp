/*-----------------------------------------------------------------------

PROGRAM: DtConsole.cpp

PURPOSE:
Open Layers data acquisition example showing how to implement a 
continuous analog input operation using windows messaging in a 
console environment.

****************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "oldaapi.h"


FILE *fsignal;
FILE *fcoeff;
FILE *foutput;
float filtered_output[25000] = {0.0};
HDASS hAD2;
float filter_coeff[201] = {0.0};
int get_filter_coeff = 0;
int get_signalBuffer = 0;
int buff_size = 0;
float samp;

DBL min=0,max=0;		
DBL volts0;
ULNG value0;
DBL volts1;
ULNG value1;
ULNG samples;
UINT encoding=0,resolution=0;
HBUF  hBuf = NULL;
PDWORD  pBuffer32 = NULL;
PWORD  pBuffer = NULL;
double signalBuffer[50000];
char WindowTitle[128];
char temp[128];

#define CHECKERROR( ecode )                           \
	do                                                    \
{                                                     \
	ECODE olStatus;                                    \
	if( OLSUCCESS != ( olStatus = ( ecode ) ) )        \
{                                                  \
	printf("OpenLayers Error %d\n", olStatus );  \
	exit(1);                                        \
}                                                  \
}                                                     \
	while(0)      

#define NUM_OL_BUFFERS 4

int counter = 0;


int get_coeff()
{
	int i=0; 	 
	if(get_filter_coeff == 0)
	{
		while(fscanf(fcoeff,"%f\n",&filter_coeff[i])!=EOF)
			i++;
	}
	get_filter_coeff = 1;
	return 1; 
}


void get_signal()
{	float volt;
int j = 0;
printf("Inside signal\n");
for(int i = 0; i<samp; i+=2)
{
	volt = (20.0/(1L<<16)*pBuffer[i]) - 10;
	signalBuffer[j++] = volt;	
	buff_size++;
}
for( int i=0;i<buff_size;i++)
	fprintf(fsignal,"%f\n",signalBuffer[i]);

}

/* Filter section */


void filter()
{
	float sum = 0.0, avg_value = 0.0;
	int i,j;
	float value = 0.0;
	static float max_value;
	int condition=0;
	//printf("Inside filter\n");
	condition = get_coeff();

	//get_signal();

#pragma omp parallel for reduction (+:sum) private(i,j,value) num_threads(3) 
	for(i=buff_size; i>0;i--)
	{
		sum = 0.0;
		for(j=0;j<201;j++)
		{
			if(i>j)
			{
				value = filter_coeff[j] * signalBuffer[i-j];
				sum += value;
			}
		}

		filtered_output[i] = sum;
		if(sum>max_value)
			max_value = sum;
		avg_value += max_value;
	}

	printf("Writing to file\n");
	// write to output file
	for(i=0; i<buff_size;i++)
		fprintf(foutput,"%f\n",filtered_output[i]);

}

LRESULT WINAPI 
	WndProc( HWND hWnd, UINT msg, WPARAM hAD, LPARAM lParam )
{
	int j=0;
	double sample1[50000]= {};
	double sample2[50000]= {};

	switch( msg )
	{
	case OLDA_WM_BUFFER_DONE:
		counter++;
		printf( "Buffer Done Count : %ld \r", counter );
		HBUF hBuf;
		//counter++;
		//olDaGetBuffer( (HDASS)hAD, &hBuf );
		//olDaPutBuffer( (HDASS)hAD, hBuf );
		CHECKERROR (olDaGetBuffer((HDASS)hAD, &hBuf));

		/* if there is a buffer */

		if( hBuf )
		{

			/* get sub system information for code/volts conversion */

			CHECKERROR (olDaGetRange((HDASS)hAD,&max,&min));
			CHECKERROR (olDaGetEncoding((HDASS)hAD,&encoding));
			CHECKERROR (olDaGetResolution((HDASS)hAD,&resolution));

			/* get max samples in input buffer */

			CHECKERROR (olDmGetValidSamples( hBuf, &samples ) );

			/* get pointer to the buffer */
			if (resolution > 16)
			{
				CHECKERROR (olDmGetBufferPtr( hBuf,(LPVOID*)&pBuffer32));
				/* get last sample in buffer */

				for (int i=0;i<samples;i+=2){
					value0 = pBuffer32[i-1];
					value1 = pBuffer32[i];
					//sample1[i]=value0;
					//sample2[i]=value1;
				}
			}
			else
			{

				CHECKERROR (olDmGetBufferPtr( hBuf,(LPVOID*)&pBuffer));
				/* get last sample in buffer */
				for (int i=0;i<samples;i+=2){
				value0 = pBuffer[i-1];
				value1 = pBuffer[i];
				volts1 = ((float)max-(float)min)/(1L<<resolution)*value1 + (float)min;
				volts0 = ((float)max-(float)min)/(1L<<resolution)*value0 + (float)min;
				signalBuffer[i] = volts1;
				fprintf(fsignal,"%lf\n",signalBuffer[i]);
				buff_size++;
				//value0 = pBuffer[samples-1];
			//value1 = pBuffer[samples-2];
				
				}
			}
			/* put buffer back to ready list */

			CHECKERROR (olDaPutBuffer((HDASS)hAD, hBuf));

			/*  convert value to volts */

			if (encoding != OL_ENC_BINARY) 
			{
				/* convert to offset binary by inverting the sign bit */

				value0 ^= 1L << (resolution-1);
				value0 &= (1L << resolution) - 1;     /* zero upper bits */
				value1 ^= 1L << (resolution-1);
				value1 &= (1L << resolution) - 1; 
			}

			//volts0 = ((float)max-(float)min)/(1L<<resolution)*value0 + (float)min;
			//for(){
			//volts1 = ((float)max-(float)min)/(1L<<resolution)*value1 + (float)min;
			//signalBuffer[j] = volts1;
			//fprintf(fsignal,"%lf\n",signalBuffer[j]);
			//j++;
			//}
			if(volts0 > 0)
			{
				filter();
				CHECKERROR (olDaPutSingleValue(hAD2,1,0,1));
			}
			else
			{
				CHECKERROR (olDaPutSingleValue(hAD2,0,0,1));
			}
		}

		break;

	case OLDA_WM_QUEUE_DONE:
		printf( "\nAcquisition stopped, rate too fast for current options." );
		PostQuitMessage(0);
		break;

	case OLDA_WM_TRIGGER_ERROR:
		printf( "\nTrigger error: acquisition stopped." );
		PostQuitMessage(0);
		break;

	case OLDA_WM_OVERRUN_ERROR:
		printf( "\nInput overrun error: acquisition stopped." );
		PostQuitMessage(0);
		break;

	default: 
		return DefWindowProc( hWnd, msg, hAD, lParam );
	}

	// return 0;
}


BOOL CALLBACK 
	EnumBrdProc( LPSTR lpszBrdName, LPSTR lpszDriverName, LPARAM lParam )
{

	// Make sure we can Init Board
	if( OLSUCCESS != ( olDaInitialize( lpszBrdName, (LPHDEV)lParam ) ) )
	{
		return TRUE;  // try again
	}

	// Make sure Board has an A/D Subsystem 
	UINT uiCap = 0;
	olDaGetDevCaps ( *((LPHDEV)lParam), OLDC_ADELEMENTS, &uiCap );
	if( uiCap < 1 )
	{
		return TRUE;  // try again
	}

	printf( "%s succesfully initialized.\n", lpszBrdName );
	return FALSE;    // all set , board handle in lParam
}



int main()
{	
	foutput = fopen("C:\\Users\\M S Raghavendra S\\Desktop\\Lab4\\Output.txt","wb");
	fsignal = fopen("C:\\Users\\M S Raghavendra S\\Desktop\\Lab4\\Signal.txt","wb");
	//handle to the filter coefficients
	fcoeff = fopen("C:\\Users\\M S Raghavendra S\\Desktop\\Lab4\\FIR_400.txt","rb");
	if(fcoeff == NULL)
	{
		printf("File not found");
		return 0;
	}

	printf( "Open Layers Continuous A/D Win32 Console Example\n" );

	// create a window for messages
	WNDCLASS wc;
	memset( &wc, 0, sizeof(wc) );
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = "DtConsoleClass";
	RegisterClass( &wc );

	HWND hWnd = CreateWindow( wc.lpszClassName,
		NULL, 
		NULL, 
		0, 0, 0, 0,
		NULL,
		NULL,
		NULL,
		NULL );

	if( !hWnd )
		exit( 1 );

	HDEV hDev = NULL;
	CHECKERROR( olDaEnumBoards( EnumBrdProc, (LPARAM)&hDev ) );

	HDASS hAD = NULL;
	CHECKERROR( olDaGetDASS( hDev, OLSS_AD, 0, &hAD ) ); 

	CHECKERROR( olDaSetWndHandle( hAD, hWnd, 0 ) ); 

	CHECKERROR( olDaSetDataFlow( hAD, OL_DF_CONTINUOUS ) ); 
	CHECKERROR( olDaSetChannelListSize( hAD, 2 ) );
	CHECKERROR( olDaSetChannelListEntry( hAD, 0, 0 ) );
	CHECKERROR( olDaSetChannelListEntry( hAD, 1, 1 ) );
	CHECKERROR( olDaSetGainListEntry( hAD, 0, 1 ) );
	CHECKERROR( olDaSetTrigger( hAD, OL_TRG_SOFT ) );
	CHECKERROR( olDaSetClockSource( hAD, OL_CLK_INTERNAL ) ); 
	printf("Enter the sampling frequency");
	scanf("%f", &samp);
	CHECKERROR( olDaSetClockFrequency( hAD, samp) );
	CHECKERROR( olDaSetWrapMode( hAD, OL_WRP_NONE ) );
	CHECKERROR( olDaConfig( hAD ) );
	CHECKERROR (olDaGetDASS(hDev,OLSS_DOUT,0,&hAD2));
	CHECKERROR (olDaSetDataFlow(hAD2,OL_DF_SINGLEVALUE));
	CHECKERROR (olDaConfig(hAD2));


	HBUF hBufs[NUM_OL_BUFFERS];
	for( int i=0; i < NUM_OL_BUFFERS; i++ )
	{
		if( OLSUCCESS != olDmAllocBuffer( GHND, samp, &hBufs[i] ) )
		{
			for ( i--; i>=0; i-- )
			{
				olDmFreeBuffer( hBufs[i] );
			}   
			exit( 1 );   
		}
		olDaPutBuffer( hAD,hBufs[i] );
	}

	if( OLSUCCESS != ( olDaStart( hAD ) ) )
	{
		printf( "A/D Operation Start Failed...hit any key to terminate.\n" );
	}
	else
	{
		printf( "A/D Operation Started...hit any key to terminate.\n\n" );
		printf( "Buffer Done Count : %ld \r", counter );
	}   

	MSG msg;                                    
	SetMessageQueue( 50 );                      // Increase the our message queue size so
	// we don't lose any data acq messages

	// Acquire and dispatch messages until a key is hit...since we are a console app 
	// we are using a mix of Windows messages for data acquistion and console approaches
	// for keyboard input.
	//
	while( GetMessage( &msg,        // message structure              
		hWnd,        // handle of window receiving the message 
		0,           // lowest message to examine          
		0 ) )        // highest message to examine         
	{
		TranslateMessage( &msg );    // Translates virtual key codes       
		DispatchMessage( &msg );     // Dispatches message to window 
		if( _kbhit() )
		{
			_getch();
			PostQuitMessage(0);      
		}
	}

	// abort A/D operation
	olDaAbort( hAD );
	printf( "\nA/D Operation Terminated \n" );

	for(int i=0; i<NUM_OL_BUFFERS; i++ ) 
	{
		olDmFreeBuffer( hBufs[i] );
	}   
	fclose(foutput);
	fclose(fsignal);
	fclose(fcoeff);
	olDaTerminate( hDev );
	exit( 0 );

}

